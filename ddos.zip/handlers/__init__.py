from . import osnova,qiwi,admin,ddos
