from aiogram.dispatcher.filters.state import State, StatesGroup

class st(StatesGroup):

	url = State()
	tim = State(1)